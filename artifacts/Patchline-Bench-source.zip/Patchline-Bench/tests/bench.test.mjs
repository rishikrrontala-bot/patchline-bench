import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {generateWindow,validateWindow,extractFeatures,FAMILIES,toCSV} from '../app/simulator.js';
import {predict,validateModel} from '../app/inference.js';
import {assess,createRehearsal} from '../app/policy.js';
const model=JSON.parse(fs.readFileSync(new URL('../model/model.json',import.meta.url)));
const clone=x=>JSON.parse(JSON.stringify(x));
for(const family of FAMILIES)test(`${family}: deterministic, frozen, bounded across 100 seeds`,()=>{for(let s=1;s<=100;s++){const w=generateWindow(family,s);assert.deepEqual(w,generateWindow(family,s));assert.ok(Object.isFrozen(w.samples[0]));assert.equal(extractFeatures(w).length,24);validateWindow(w);}});
test('metadata cannot influence features or prediction',()=>{const w=clone(generateWindow('shift',912));const a=extractFeatures(w);w.family='steady';w.seed=111;assert.deepEqual(extractFeatures(w),a);assert.deepEqual(predict(w,model),predict({...w,family:'sensor_fault'},model));});
test('known linear signal features and translated elapsed times',()=>{const w=clone(generateWindow('steady',9));w.samples=w.samples.map((s,i)=>({...s,ph:i/2}));const f=extractFeatures(w);assert.equal(f[0],5.75);assert.equal(f[2],.5);assert.equal(f[3],11.5);assert.equal(f[4],11.5);w.samples.forEach(s=>s.t+=999999000);assert.deepEqual(extractFeatures(w),f);});
test('null stays missing and cannot produce nonfinite features',()=>{const w=clone(generateWindow('steady',9));w.samples.forEach(s=>s.ph=null);assert.deepEqual(extractFeatures(w).slice(0,6),[0,0,0,0,0,1]);assert.ok(assess(w,predict(w,model)).reasons.some(x=>x.includes('missing')));assert.match(toCSV(w),/0,,/);});
for(const change of [w=>w.samples[1].t=0,w=>w.samples[0].ph=NaN,w=>w.samples[0].glucose=6,w=>w.extra=true,w=>delete w.samples[2],w=>w.samples.extra=1])test(`reject invalid window ${String(change)}`,()=>{const w=clone(generateWindow('steady',9));change(w);assert.throws(()=>validateWindow(w));});
test('reject getter without executing it',()=>{let called=false;const w=clone(generateWindow('steady',9));Object.defineProperty(w.samples,'0',{get(){called=true;throw new Error('executed');}});assert.throws(()=>validateWindow(w),/Accessors/);assert.equal(called,false);});
test('all 1800 run seeds disjoint; scaler fitted on training only',()=>{const sets=['train','validation','test'].map(n=>JSON.parse(fs.readFileSync(new URL(`../data/${n}.json`,import.meta.url))));assert.equal(new Set(sets.flat().map(r=>r.seed)).size,1800);for(let i=0;i<24;i++){const mean=sets[0].reduce((s,r)=>s+r.features[i],0)/sets[0].length;assert.ok(Math.abs(mean-model.mean[i])<1e-12);}});
test('JS inference agrees with independent NumPy forward pass',()=>{const rows=JSON.parse(fs.readFileSync(new URL('../proof/inference-parity.json',import.meta.url)));assert.ok(rows.length>=30);const source=JSON.parse(fs.readFileSync(new URL('../data/test.json',import.meta.url)));for(let i=0;i<rows.length;i++){const p=predict(source[rows[i].index??i].window,model);assert.equal(p.status,'estimated');p.probabilities.forEach((x,j)=>assert.ok(Math.abs(x-rows[i].probabilities[j])<1e-12));}});
test('invalid model rejected, wrong-size window abstains',()=>{const bad=clone(model);bad.scale[0]=0;assert.throws(()=>validateModel(bad));assert.equal(predict(generateWindow('steady',3,8),model).status,'abstain');});
test('manual approval is one use, bound to current window, held readings cannot run',()=>{const r=createRehearsal();const p={status:'estimated',label:'steady',confidence:.99};const w=generateWindow('steady',123);assert.throws(()=>r.run());assert.equal(r.load(w,p).state,'review');r.approve();assert.equal(r.run().hardwareActuation,false);assert.throws(()=>r.run());r.approve();r.load(generateWindow('steady',124),p);assert.throws(()=>r.run());r.load({...w,provenance:'bench',family:null,seed:null},p);assert.throws(()=>r.approve());});
test('stuck sensor is held independently of classifier',()=>{const w=clone(generateWindow('steady',3));w.samples.slice(3,7).forEach(s=>s.moisture=44);assert.equal(assess(w,{status:'estimated',label:'steady',confidence:1}).state,'hold');});
import {parseFrame,createFrameBuffer} from '../app/telemetry.js';
const frame=(seq=0,t=seq)=>({schema:'patchline-bench-frame-v1',seq,t,provenance:'synthetic',ph:7,temperature:27,moisture:45,glucose:.6,raw:{ph_v:null,moisture_v:null,glucose_v:null},status:{ph:'simulated',temperature:'simulated',moisture:'simulated',glucose:'simulated'},hardware_actuation:false});
test('24 firmware frames become bench provenance and hold',()=>{const b=createFrameBuffer();let w;for(let i=0;i<24;i++)w=b.push(JSON.stringify(frame(i)));assert.equal(w.provenance,'bench');assert.equal(assess(w,predict(w,model)).state,'hold');});
test('telemetry rejects unsafe, oversized, contradictory or discontinuous frames',()=>{assert.throws(()=>parseFrame('x'.repeat(4097)));const f=frame();f.hardware_actuation=true;assert.throws(()=>parseFrame(JSON.stringify(f)));f.hardware_actuation=false;f.status.ph='uncalibrated';assert.throws(()=>parseFrame(JSON.stringify(f)));const b=createFrameBuffer();b.push(JSON.stringify(frame(0)));assert.throws(()=>b.push(JSON.stringify(frame(2))),/discontinuity/);assert.equal(b.push(JSON.stringify(frame(3))),null);});
test('reset invalidates manual approval',()=>{const r=createRehearsal();r.load(generateWindow('steady',9),{status:'estimated',label:'steady',confidence:.99});r.approve();r.clear();assert.throws(()=>r.run());assert.throws(()=>r.approve());});
test('invalid model outputs fail closed',()=>{const w=generateWindow('steady',9);for(const p of [null,{}, {status:'estimated',label:'steady',confidence:NaN},{status:'estimated',label:'infection',confidence:1},{status:'estimated',label:'steady',confidence:2}])assert.equal(assess(w,p).state,'hold');});

test('USB arrival timeout discards old frames even when device sequence stays contiguous',()=>{
 let arrival=0;const b=createFrameBuffer(()=>arrival);let w;
 for(let i=0;i<23;i++){arrival=i*100;assert.equal(b.push(JSON.stringify(frame(i))),null);}
 arrival+=10001;
 assert.equal(b.push(JSON.stringify(frame(23))),null);
 for(let i=24;i<46;i++){arrival+=100;assert.equal(b.push(JSON.stringify(frame(i))),null);}
 arrival+=100;w=b.push(JSON.stringify(frame(46)));
 assert.equal(w.samples.length,24);assert.equal(w.samples[0].t,23);assert.equal(w.samples[23].t,46);
});
test('malformed telemetry and a backwards arrival clock restart collection',()=>{
 let arrival=100;const b=createFrameBuffer(()=>arrival);
 for(let i=0;i<23;i++)b.push(JSON.stringify(frame(i)));
 assert.throws(()=>b.push('{broken'));
 assert.equal(b.push(JSON.stringify(frame(23))),null);
 arrival=99;assert.equal(b.push(JSON.stringify(frame(24))),null);
 for(let i=25;i<47;i++)assert.equal(b.push(JSON.stringify(frame(i))),null);
 assert.equal(b.push(JSON.stringify(frame(47))).samples[0].t,24);
});
